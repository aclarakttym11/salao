const { Pool } = require('pg');
const { URL } = require('url');

let pool;

// Lê configs do ambiente. Exemplos:
// DATABASE_URL=postgres://user:pass@localhost:5432/salao
// ou usar variáveis separadas PGHOST, PGPORT, PGUSER, PGPASSWORD, PGDATABASE
function createPool() {
  if (process.env.DATABASE_URL) {
    return new Pool({ connectionString: process.env.DATABASE_URL });
  }
  return new Pool({
    host: process.env.PGHOST || 'localhost',
    port: Number(process.env.PGPORT || 5432),
    user: process.env.PGUSER || 'postgres',
    password: process.env.PGPASSWORD || 'klar1ta07',
    database: process.env.PGDATABASE || 'salao',
  });
}

async function initDb() {
  if (pool) return pool;
  pool = createPool();
  let client;
  try {
    client = await pool.connect();
  } catch (err) {
    // Se o banco não existir, tenta criar automaticamente conectando ao DB postgres
    if (err && err.code === '3D000') {
      const cfg = process.env.DATABASE_URL || null;
      let adminPool;
      if (cfg) {
        const u = new URL(cfg);
        const targetDb = u.pathname.replace(/^\//, '') || 'salao';
        u.pathname = '/postgres';
        adminPool = new Pool({ connectionString: u.toString() });
        const admin = await adminPool.connect();
        try {
          const { rows } = await admin.query(
            'SELECT 1 FROM pg_database WHERE datname = $1',
            [targetDb]
          );
          if (rows.length === 0) {
            await admin.query(`CREATE DATABASE ${JSON.stringify(targetDb).slice(1, -1)}`);
          }
        } finally {
          admin.release();
          await adminPool.end();
        }
      } else {
        // usando variáveis separadas
        const host = process.env.PGHOST || 'localhost';
        const port = Number(process.env.PGPORT || 5432);
        const user = process.env.PGUSER || 'postgres';
        const password = process.env.PGPASSWORD || 'klar1ta07';
        const database = process.env.PGDATABASE || 'salao';
        adminPool = new Pool({ host, port, user, password, database: 'postgres' });
        const admin = await adminPool.connect();
        try {
          const { rows } = await admin.query(
            'SELECT 1 FROM pg_database WHERE datname = $1',
            [database]
          );
          if (rows.length === 0) {
            await admin.query(`CREATE DATABASE ${JSON.stringify(database).slice(1, -1)}`);
          }
        } finally {
          admin.release();
          await adminPool.end();
        }
      }
      // tenta conectar de novo ao banco alvo
      pool = createPool();
      client = await pool.connect();
    } else {
      throw err;
    }
  }

  try {
    await client.query('BEGIN');

    // Tabela de clientes (modelo atual da aplicação)
    await client.query(`
      CREATE TABLE IF NOT EXISTS customers (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        notes TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Tabela de agendamentos (modelo atual da aplicação)
    await client.query(`
      CREATE TABLE IF NOT EXISTS appointments (
        id SERIAL PRIMARY KEY,
        customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
        start_at TIMESTAMPTZ NOT NULL,
        service TEXT,
        notes TEXT,
        status TEXT DEFAULT 'scheduled',
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Índices básicos para o modelo atual
    await client.query(
      'CREATE INDEX IF NOT EXISTS idx_appt_start_at ON appointments(start_at)'
    );
    await client.query(
      'CREATE INDEX IF NOT EXISTS idx_appt_customer ON appointments(customer_id)'
    );

    // --- Estruturas extras seguindo o script do salão (clientes/servicos/agendamentos) ---

    // Tabela clientes (modelo alternativo)
    await client.query(`
      CREATE TABLE IF NOT EXISTS clientes (
        id SERIAL PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100),
        telefone VARCHAR(20)
      )
    `);

    // Tabela servicos
    await client.query(`
      CREATE TABLE IF NOT EXISTS servicos (
        id SERIAL PRIMARY KEY,
        nome VARCHAR(100) NOT NULL UNIQUE,
        preco NUMERIC(10,2)
      )
    `);

    // Tabela agendamentos (modelo alternativo)
    await client.query(`
      CREATE TABLE IF NOT EXISTS agendamentos (
        id SERIAL PRIMARY KEY,
        cliente_id INT REFERENCES clientes(id),
        servico_id INT REFERENCES servicos(id),
        data_hora TIMESTAMP NOT NULL
      )
    `);

    // Dados iniciais de servicos (sem duplicar pelo nome, sem depender de ON CONFLICT)
    await client.query(`
      INSERT INTO servicos (nome, preco)
      SELECT v.nome, v.preco
      FROM (VALUES
        ('Corte de cabelo', 30.00),
        ('Manicure', 25.00),
        ('Pedicure', 35.00)
      ) AS v(nome, preco)
      WHERE NOT EXISTS (
        SELECT 1 FROM servicos s WHERE s.nome = v.nome
      )
    `);

    // Procedure cadastrar_cliente
    await client.query(`
      CREATE OR REPLACE PROCEDURE cadastrar_cliente(
        p_nome VARCHAR,
        p_email VARCHAR,
        p_telefone VARCHAR
      )
      LANGUAGE plpgsql
      AS $$
      BEGIN
        INSERT INTO clientes (nome, email, telefone)
        VALUES (p_nome, p_email, p_telefone);
      END;
      $$;
    `);

    // Função total_agendamentos
    await client.query(`
      CREATE OR REPLACE FUNCTION total_agendamentos()
      RETURNS INT AS $$
      DECLARE
        total INT;
      BEGIN
        SELECT COUNT(*) INTO total FROM agendamentos;
        RETURN total;
      END;
      $$ LANGUAGE plpgsql;
    `);

    // Função de trigger para verificar_horario
    await client.query(`
      CREATE OR REPLACE FUNCTION verificar_horario()
      RETURNS TRIGGER AS $$
      BEGIN
        IF EXISTS (
          SELECT 1 FROM agendamentos
          WHERE data_hora = NEW.data_hora
        ) THEN
          RAISE EXCEPTION 'Horário já ocupado';
        END IF;
        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;
    `);

    // Trigger usando a função verificar_horario (cria só se não existir)
    await client.query(`
      DO $$
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_trigger
          WHERE tgname = 'trg_verificar_horario'
        ) THEN
          CREATE TRIGGER trg_verificar_horario
          BEFORE INSERT ON agendamentos
          FOR EACH ROW
          EXECUTE FUNCTION verificar_horario();
        END IF;
      END;
      $$;
    `);

    await client.query('COMMIT');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
  return pool;
}

function getDb() {
  if (!pool) throw new Error('DB não inicializado. Chame initDb() antes.');
  return pool;
}

module.exports = { initDb, getDb };