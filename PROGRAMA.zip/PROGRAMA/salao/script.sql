-- Cria o banco de dados
CREATE DATABASE salao;

-- Conecta ao banco (no psql)
\c salao;

-- Tabela de clientes
CREATE TABLE clientes (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telefone VARCHAR(20)
);

-- Tabela de serviços
CREATE TABLE servicos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    preco NUMERIC(10,2)
);

-- Tabela de agendamentos
CREATE TABLE agendamentos (
    id SERIAL PRIMARY KEY,
    cliente_id INT REFERENCES clientes(id),
    servico_id INT REFERENCES servicos(id),
    data_hora TIMESTAMP NOT NULL
);

-- Dados iniciais de serviços
INSERT INTO servicos (nome, preco) VALUES
    ('Corte de cabelo', 30.00),
    ('Manicure', 25.00),
    ('Pedicure', 35.00);

-- Procedure para cadastrar cliente
CREATE OR REPLACE PROCEDURE cadastrar_cliente(
    p_nome VARCHAR,
    p_email VARCHAR,
    p_telefone VARCHAR
)
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO clientes (nome, email, telefone)
    VALUES (p_nome, p_email, p_telefone);
END;
$$;

-- Função para total de agendamentos
CREATE OR REPLACE FUNCTION total_agendamentos()
RETURNS INT AS $$
DECLARE
    total INT;
BEGIN
    SELECT COUNT(*) INTO total FROM agendamentos;
    RETURN total;
END;
$$ LANGUAGE plpgsql;

-- Trigger para verificar horário ocupado
CREATE OR REPLACE FUNCTION verificar_horario()
RETURNS TRIGGER AS $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM agendamentos
        WHERE data_hora = NEW.data_hora
    ) THEN
        RAISE EXCEPTION 'Horário já ocupado';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_verificar_horario
BEFORE INSERT ON agendamentos
FOR EACH ROW
EXECUTE FUNCTION verificar_horario();