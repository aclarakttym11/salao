const express = require('express');
const router = express.Router();
const { getDb } = require('../db');

// Listar clientes (com pesquisa opcional ?q=)
router.get('/', async (req, res) => {
  try {
    const pool = getDb();
    const q = (req.query.q || '').trim();
    let result;
    if (q) {
      const like = `%${q}%`;
      result = await pool.query(
        'SELECT * FROM customers WHERE name ILIKE $1 OR phone ILIKE $1 OR email ILIKE $1 ORDER BY created_at DESC',
        [like]
      );
    } else {
      result = await pool.query('SELECT * FROM customers ORDER BY created_at DESC');
    }
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao listar clientes' });
  }
});

// Obter cliente por ID
router.get('/:id', async (req, res) => {
  try {
    const pool = getDb();
    const { rows } = await pool.query('SELECT * FROM customers WHERE id = $1', [req.params.id]);
    const row = rows[0];
    if (!row) return res.status(404).json({ error: 'Cliente não encontrado' });
    res.json(row);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar cliente' });
  }
});

// Criar cliente
router.post('/', async (req, res) => {
  try {
    const pool = getDb();
    const { name, phone, email, notes } = req.body || {};
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Nome é obrigatório' });
    }
    const { rows } = await pool.query(
      'INSERT INTO customers (name, phone, email, notes) VALUES ($1, $2, $3, $4) RETURNING *',
      [name.trim(), phone || null, email || null, notes || null]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao criar cliente' });
  }
});

// Atualizar cliente
router.put('/:id', async (req, res) => {
  try {
    const pool = getDb();
    const { name, phone, email, notes } = req.body || {};
    const { rows: existingRows } = await pool.query('SELECT * FROM customers WHERE id = $1', [req.params.id]);
    const existing = existingRows[0];
    if (!existing) return res.status(404).json({ error: 'Cliente não encontrado' });

    const newName = (name ?? existing.name).trim();
    if (!newName) return res.status(400).json({ error: 'Nome é obrigatório' });

    const { rows } = await pool.query(
      'UPDATE customers SET name = $1, phone = $2, email = $3, notes = $4 WHERE id = $5 RETURNING *',
      [newName, phone ?? existing.phone, email ?? existing.email, notes ?? existing.notes, req.params.id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao atualizar cliente' });
  }
});

// Remover cliente (cascateia agendamentos)
router.delete('/:id', async (req, res) => {
  try {
    const pool = getDb();
    const result = await pool.query('DELETE FROM customers WHERE id = $1', [req.params.id]);
    if (result.rowCount === 0) return res.status(404).json({ error: 'Cliente não encontrado' });
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao remover cliente' });
  }
});

module.exports = router;
