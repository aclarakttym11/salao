const express = require('express');
const router = express.Router();
const { getDb } = require('../db');

// Listar agendamentos (opcional ?from=YYYY-MM-DD&to=YYYY-MM-DD)
router.get('/', async (req, res) => {
  try {
    const pool = getDb();
    const { from, to } = req.query;
    let rows;
    if (from && to) {
      const fromIso = new Date(from).toISOString();
      const toIso = new Date(new Date(to).getTime() + 24 * 60 * 60 * 1000).toISOString();
      const result = await pool.query(
        `SELECT a.*, c.name AS customer_name
         FROM appointments a
         JOIN customers c ON c.id = a.customer_id
         WHERE a.start_at >= $1 AND a.start_at < $2
         ORDER BY a.start_at ASC`,
        [fromIso, toIso]
      );
      rows = result.rows;
    } else {
      const result = await pool.query(
        `SELECT a.*, c.name AS customer_name
         FROM appointments a
         JOIN customers c ON c.id = a.customer_id
         ORDER BY a.start_at DESC`
      );
      rows = result.rows;
    }
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao listar agendamentos' });
  }
});

// Criar agendamento
router.post('/', async (req, res) => {
  try {
    const pool = getDb();
    const { customer_id, date, time, start_at, service, notes, status } = req.body || {};

    const cid = Number(customer_id);
    if (!cid || Number.isNaN(cid)) return res.status(400).json({ error: 'customer_id inválido' });

    let startAt = start_at;
    if (!startAt && date && time) startAt = new Date(`${date}T${time}:00`).toISOString();
    if (!startAt) return res.status(400).json({ error: 'Informe start_at ou (date + time)' });

    const { rows: custRows } = await pool.query('SELECT id FROM customers WHERE id = $1', [cid]);
    if (!custRows[0]) return res.status(404).json({ error: 'Cliente não encontrado' });

    const { rows } = await pool.query(
      `INSERT INTO appointments (customer_id, start_at, service, notes, status)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [cid, startAt, service || null, notes || null, status || 'scheduled']
    );

    const createdId = rows[0].id;
    const { rows: created } = await pool.query(
      `SELECT a.*, c.name AS customer_name
       FROM appointments a JOIN customers c ON c.id = a.customer_id
       WHERE a.id = $1`,
      [createdId]
    );
    res.status(201).json(created[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao criar agendamento' });
  }
});

// Atualizar agendamento
router.put('/:id', async (req, res) => {
  try {
    const pool = getDb();
    const { rows: existRows } = await pool.query('SELECT * FROM appointments WHERE id = $1', [req.params.id]);
    const existing = existRows[0];
    if (!existing) return res.status(404).json({ error: 'Agendamento não encontrado' });

    const { customer_id, start_at, date, time, service, notes, status } = req.body || {};
    let startAt = start_at;
    if (!startAt && date && time) startAt = new Date(`${date}T${time}:00`).toISOString();

    const newCustomerId = customer_id ? Number(customer_id) : existing.customer_id;
    if (Number.isNaN(newCustomerId)) return res.status(400).json({ error: 'customer_id inválido' });

    const { rows } = await pool.query(
      `UPDATE appointments
         SET customer_id = $1, start_at = $2, service = $3, notes = $4, status = $5
       WHERE id = $6
       RETURNING *`,
      [
        newCustomerId,
        startAt || existing.start_at,
        service ?? existing.service,
        notes ?? existing.notes,
        status ?? existing.status,
        req.params.id,
      ]
    );

    const { rows: joined } = await pool.query(
      `SELECT a.*, c.name AS customer_name
       FROM appointments a JOIN customers c ON c.id = a.customer_id
       WHERE a.id = $1`,
      [rows[0].id]
    );
    res.json(joined[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao atualizar agendamento' });
  }
});

// Remover agendamento
router.delete('/:id', async (req, res) => {
  try {
    const pool = getDb();
    const result = await pool.query('DELETE FROM appointments WHERE id = $1', [req.params.id]);
    if (result.rowCount === 0) return res.status(404).json({ error: 'Agendamento não encontrado' });
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao remover agendamento' });
  }
});

module.exports = router;
