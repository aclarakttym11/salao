# Salão — Clientes e Agendamentos
Aplicação full‑stack simples para gestão de **clientes** e **agendamentos** de um salão.

- Backend em **Node.js + Express** servindo API REST e arquivos estáticos.
- Banco de dados **PostgreSQL** com criação automática de tabelas.
- Frontend em **React 18** carregado via CDN (sem build tooling, tudo dentro de `public/`).

---

## Requisitos

- **Node.js** 18+ (recomendado Node 20)
- **npm** (vem junto com o Node)
- **PostgreSQL** 13+ em execução local ou remoto

---

## Configuração do banco de dados

O backend usa PostgreSQL via `pg.Pool`. É possível configurar a conexão de duas formas:

- Usando uma URL única:
  - `DATABASE_URL` — ex.: `postgres://usuario:senha@localhost:5432/salao`

  **ou**

- Usando variáveis separadas:
  - `PGHOST` (padrão: `localhost`)
  - `PGPORT` (padrão: `5432`)
  - `PGUSER` (padrão: `postgres`)
  - `PGPASSWORD`
  - `PGDATABASE` (padrão: `salao`)

Se o banco de dados informado ainda **não existir**, o código tenta criá‑lo automaticamente
conectando ao banco `postgres`.

### Criando o banco manualmente (opcional)

Com o `psql` instalado, você pode criar antes o banco `salao`:

```bash
psql -U postgres -h localhost -c "CREATE DATABASE salao;"
```

Também existe o arquivo `script.sql` com um modelo alternativo de tabelas, procedures e triggers.
Ele é **opcional** — o backend já cria as tabelas que usa (`customers` e `appointments`) via `db.js`.

> Dica: crie um arquivo `.env` (ou exporte variáveis no terminal) com seus dados reais,
> sem versionar senhas.

---

## Instalação

Na raiz do projeto:

```bash
npm install
```

Isso instalará as dependências do backend (`express`, `pg`, `cors`, `morgan`).

---

## Execução

Ainda na raiz do projeto:

```bash
npm start
```

O servidor sobe (por padrão) em `http://localhost:3000`.

Ao acessar essa URL, o backend serve o conteúdo de `public/` (SPA em React) que consome a API.

---

## Estrutura do projeto

- `server.js`
  - Configuração do **Express**.
  - Middlewares básicos (`morgan`, `express.json`, `cors`).
  - Servir estáticos de `public/`.
  - Rotas de API: `/api/customers` e `/api/appointments`.
  - Rota `/health` para verificação rápida.
  - Fallback `*` enviando `public/index.html` (SPA).

- `db.js`
  - Criação e export do pool (`pg.Pool`).
  - `initDb()` cria (se não existirem):
    - Tabela `customers` (modelo principal de clientes).
    - Tabela `appointments` com FK para `customers` (e alguns índices).
    - Estruturas adicionais compatíveis com `script.sql` (`clientes`, `servicos`, `agendamentos`, procedure, função, trigger).

- `routes/customers.js`
  - CRUD de clientes em `/api/customers`.
  - Suporte a busca por query string `?q=` (nome, email ou telefone).

- `routes/appointments.js`
  - CRUD de agendamentos em `/api/appointments`.
  - Permite listar por período com `?from=YYYY-MM-DD&to=YYYY-MM-DD`.
  - Garante que o `customer_id` exista.

- `public/index.html`
  - HTML base.
  - Carrega React/ReactDOM via CDN e Babel Standalone para suportar JSX no navegador.

- `public/app.jsx`
  - Aplicação React:
    - Aba **Clientes**: cadastro, edição, remoção e busca de clientes.
    - Aba **Agendamentos**: criação, listagem, atualização de status e remoção.
  - Comunicação com a API usando `fetch`.

- `public/styles.css`
  - Estilos simples para layout, tabelas, badges de status etc.

- `script.sql`
  - Script SQL com modelo alternativo de tabelas (`clientes`, `servicos`, `agendamentos`), procedure `cadastrar_cliente`, função `total_agendamentos` e trigger de verificação de horário.

---

## Visão geral da API

### Clientes (`/api/customers`)

- `GET /api/customers`
  - Lista todos os clientes (ordenados por `created_at DESC`).
  - Suporta filtro `?q=` (nome, telefone ou email).

- `GET /api/customers/:id`
  - Retorna um cliente específico.

- `POST /api/customers`
  - Cria um cliente.
  - Body JSON esperado: `{ name, phone?, email?, notes? }`.

- `PUT /api/customers/:id`
  - Atualiza dados do cliente.

- `DELETE /api/customers/:id`
  - Remove o cliente.
  - Agendamentos vinculados em `appointments` são removidos em cascata.

### Agendamentos (`/api/appointments`)

- `GET /api/appointments`
  - Lista agendamentos, juntando `customer_name`.
  - Aceita `?from` e `?to` (datas `YYYY-MM-DD`) para filtrar por período.

- `POST /api/appointments`
  - Cria um agendamento.
  - Body JSON típico: `{ customer_id, date, time, service?, notes?, status? }`.

- `PUT /api/appointments/:id`
  - Atualiza um agendamento (status, horário, serviço, notas, etc.).

- `DELETE /api/appointments/:id`
  - Remove um agendamento.

---

## Próximos passos / ideias de melhoria

- Validações adicionais de agenda (evitar choque de horários, duração por serviço, limite diário).
- Paginação e filtros mais avançados por data/status/cliente.
- Autenticação e autorização (multiusuário, perfis de acesso).
- Tela para gerenciar a tabela `servicos` (usando as estruturas extras já criadas em `db.js`).
- Migração do frontend para Vite/CRA/Next para build otimizado quando o projeto crescer.

