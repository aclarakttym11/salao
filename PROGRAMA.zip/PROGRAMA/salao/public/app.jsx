const { useEffect, useMemo, useState } = React;

async function api(path, options = {}) {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (!res.ok) throw new Error((await res.json()).error || 'Erro');
  return res.json();
}

function Header({ view, setView }) {
  return (
    <header className="container">
      <h1>Salão — Clientes e Agendamentos</h1>
      <nav>
        <button className={view === 'customers' ? '' : 'secondary'} onClick={() => setView('customers')}>Clientes</button>
        <button className={view === 'appointments' ? '' : 'secondary'} onClick={() => setView('appointments')}>Agendamentos</button>
      </nav>
    </header>
  );
}

function CustomersView() {
  const [list, setList] = useState([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '', notes: '' });
  const [editing, setEditing] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await api(`/api/customers${q ? `?q=${encodeURIComponent(q)}` : ''}`);
      setList(data);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return alert('Nome é obrigatório');
    if (editing) {
      const updated = await api(`/api/customers/${editing.id}`, { method: 'PUT', body: JSON.stringify(form) });
      setList(prev => prev.map(x => x.id === updated.id ? updated : x));
      setEditing(null);
    } else {
      const created = await api('/api/customers', { method: 'POST', body: JSON.stringify(form) });
      setList(prev => [created, ...prev]);
    }
    setForm({ name: '', phone: '', email: '', notes: '' });
  };

  const onEdit = (c) => {
    setEditing(c);
    setForm({ name: c.name || '', phone: c.phone || '', email: c.email || '', notes: c.notes || '' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const onDelete = async (id) => {
    if (!confirm('Remover cliente? Agendamentos associados serão removidos.')) return;
    await api(`/api/customers/${id}`, { method: 'DELETE' });
    setList(prev => prev.filter(x => x.id !== id));
    if (editing?.id === id) { setEditing(null); setForm({ name: '', phone: '', email: '', notes: '' }); }
  };

  return (
    <div className="container">
      <div className="card">
        <h3 style={{marginTop: 0}}>{editing ? 'Editar Cliente' : 'Novo Cliente'}</h3>
        <form onSubmit={onSubmit} className="row">
          <div className="col">
            <label>Nome</label>
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
          </div>
          <div className="col">
            <label>Telefone</label>
            <input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div className="col">
            <label>Email</label>
            <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          </div>
          <div className="col" style={{flexBasis: '100%'}}>
            <label>Observações</label>
            <textarea rows={2} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} />
          </div>
          <div className="row" style={{width:'100%', justifyContent:'flex-end', gap:8}}>
            {editing && <button type="button" className="secondary" onClick={() => { setEditing(null); setForm({ name: '', phone: '', email: '', notes: '' }); }}>Cancelar</button>}
            <button type="submit">{editing ? 'Salvar' : 'Adicionar'}</button>
          </div>
        </form>
      </div>

      <div className="card">
        <div className="row" style={{alignItems:'flex-end'}}>
          <div className="col"><h3 style={{margin:0}}>Clientes</h3></div>
          <div className="col" style={{maxWidth: 360}}>
            <label>Pesquisar</label>
            <input placeholder="nome, telefone, email" value={q} onChange={e => setQ(e.target.value)} onKeyDown={e=>{ if(e.key==='Enter') load(); }} />
          </div>
          <div><button className="secondary" onClick={load} disabled={loading}>Buscar</button></div>
        </div>
        <table className="table">
          <thead><tr><th>Nome</th><th>Telefone</th><th>Email</th><th>Obs.</th><th></th></tr></thead>
          <tbody>
            {list.map(c => (
              <tr key={c.id}>
                <td>{c.name}</td>
                <td>{c.phone || '-'}</td>
                <td>{c.email || '-'}</td>
                <td>{c.notes || '-'}</td>
                <td style={{display:'flex', gap:8}}>
                  <button className="secondary" onClick={() => onEdit(c)}>Editar</button>
                  <button className="danger" onClick={() => onDelete(c.id)}>Remover</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function toLocal(dtIso){
  const d = new Date(dtIso);
  const date = d.toLocaleDateString();
  const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return `${date} ${time}`;
}

function AppointmentsView() {
  const [appointments, setAppointments] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [form, setForm] = useState({ customer_id: '', date: '', time: '', service: '', notes: '' });

  const load = async () => {
    const [ap, cs] = await Promise.all([
      api('/api/appointments'),
      api('/api/customers')
    ]);
    setAppointments(ap);
    setCustomers(cs);
  };

  useEffect(() => { load(); }, []);

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!form.customer_id || !form.date || !form.time) return alert('Selecione cliente, data e hora');
    const created = await api('/api/appointments', { method: 'POST', body: JSON.stringify(form) });
    setAppointments(prev => [created, ...prev]);
    setForm({ customer_id: '', date: '', time: '', service: '', notes: '' });
  };

  const updateStatus = async (appt, status) => {
    const updated = await api(`/api/appointments/${appt.id}`, { method: 'PUT', body: JSON.stringify({ status }) });
    setAppointments(prev => prev.map(a => a.id === updated.id ? updated : a));
  };

  const remove = async (id) => {
    if (!confirm('Remover agendamento?')) return;
    await api(`/api/appointments/${id}`, { method: 'DELETE' });
    setAppointments(prev => prev.filter(a => a.id !== id));
  };

  return (
    <div className="container">
      <div className="card">
        <h3 style={{marginTop: 0}}>Novo Agendamento</h3>
        <form onSubmit={onSubmit} className="row">
          <div className="col">
            <label>Cliente</label>
            <select value={form.customer_id} onChange={e => setForm({ ...form, customer_id: e.target.value })}>
              <option value="">Selecione...</option>
              {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className="col">
            <label>Data</label>
            <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} />
          </div>
          <div className="col">
            <label>Hora</label>
            <input type="time" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} />
          </div>
          <div className="col">
            <label>Serviço</label>
            <input value={form.service} onChange={e => setForm({ ...form, service: e.target.value })} />
          </div>
          <div className="col" style={{flexBasis:'100%'}}>
            <label>Observações</label>
            <textarea rows={2} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} />
          </div>
          <div className="row" style={{width:'100%', justifyContent:'flex-end', gap:8}}>
            <button type="submit">Agendar</button>
          </div>
        </form>
      </div>

      <div className="card">
        <h3 style={{marginTop: 0}}>Agendamentos</h3>
        <table className="table">
          <thead>
            <tr>
              <th>Data/Hora</th>
              <th>Cliente</th>
              <th>Serviço</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {appointments.map(a => (
              <tr key={a.id}>
                <td>{toLocal(a.start_at)}</td>
                <td>{a.customer_name}</td>
                <td>{a.service || '-'}</td>
                <td><span className={`badge ${a.status}`}>{a.status}</span></td>
                <td style={{display:'flex', gap:8}}>
                  <button className="secondary" onClick={() => updateStatus(a, 'done')}>Concluir</button>
                  <button className="secondary" onClick={() => updateStatus(a, 'canceled')}>Cancelar</button>
                  <button className="danger" onClick={() => remove(a.id)}>Remover</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function App() {
  const [view, setView] = useState('customers');
  return (
    <>
      <Header view={view} setView={setView} />
      {view === 'customers' ? <CustomersView /> : <AppointmentsView />}
      <footer>Feito com React + Node + SQLite • <a href="/health" target="_blank">health</a></footer>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
