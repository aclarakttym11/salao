const path = require('path');
const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const { initDb } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(morgan('dev'));
app.use(express.json());
app.use(cors());

// Static: frontend React simples
app.use(express.static(path.join(__dirname, 'public')));

// Rotas de API
app.use('/api/customers', require('./routes/customers'));
app.use('/api/appointments', require('./routes/appointments'));

// Healthcheck
app.get('/health', (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// Fallback para SPA (index.html)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

async function start() {
  try {
    await initDb();
    app.listen(PORT, () => {
      console.log(`Servidor rodando em http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Falha ao iniciar o banco:', err);
    process.exit(1);
  }
}

start();
